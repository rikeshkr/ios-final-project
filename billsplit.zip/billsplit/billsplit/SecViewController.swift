//
//  SecViewController.swift
//  billsplit
//
//  Created by user226769 on 9/30/22.
//

import UIKit

class SecViewController: UIViewController {
    
    // here I consider int value rather double
    var result = "0"
    //Label
    @IBOutlet weak var displayLabel: UILabel!
    // Label for showing amount
    @IBOutlet weak var Amount: UILabel!
    // for going back
    @IBAction func back(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    //for closing
    @IBAction func close(_ sender: UIButton) {
        exit(0)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        //setting the Amount label
        Amount.text = result

        // Do any additional setup after loading the view.
    }
    


}
